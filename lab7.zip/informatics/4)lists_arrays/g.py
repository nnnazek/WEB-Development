lst = []
n = int(input())
lst = input().split()
while n > 0:
    print(lst[n - 1], end = ' ')
    n -= 1