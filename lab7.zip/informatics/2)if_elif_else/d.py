a = int(input())

if a > 0:
    print(1)
elif a < 0:
    print(-1)
else:
    print(0)