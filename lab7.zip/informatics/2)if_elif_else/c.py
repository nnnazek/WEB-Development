a = int(input())
b = int(input())

if ((a == 1) ^ (b == 1)):
    print("NO")
else:
    print("YES")
