# является ли введенный год високосным
a = int(input())
if (a % 4 == 0):
    print("YES")
else:
    print("NO")