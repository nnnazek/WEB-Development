n = int(input())
i = 1
while (i <= n):
    if (i*i <= n):
        print(i*i)
    i += 1