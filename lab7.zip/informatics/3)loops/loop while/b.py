a = int(input())
i = 2
x = 2
while (i <= a):
    if ( a % i) == 0:
        print(i)
        break
    i += 1