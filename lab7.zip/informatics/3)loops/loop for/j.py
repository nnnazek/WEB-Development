ans = 0
for i in range(1,100+1):
    ans += int(input())

print(ans)