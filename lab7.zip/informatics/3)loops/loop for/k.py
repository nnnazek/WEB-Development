ans = 0

for i in range(int(input())):
    ans += int(input())
print(ans)