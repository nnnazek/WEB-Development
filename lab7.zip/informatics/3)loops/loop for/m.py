ans = 0

for i in range(int(input())):
    if int(input()) == 0:
        ans += 1
print(ans)