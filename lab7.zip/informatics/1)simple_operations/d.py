n = int(input())
k = int(input())

res = k % n
print(res)