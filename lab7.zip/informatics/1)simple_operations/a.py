import math

a = int(input())
b = int(input())
res = math.sqrt(a*a + b*b)
print(res)
