import math

n = int(input())
k = int(input())
res = math.floor(k / n)
print(res)