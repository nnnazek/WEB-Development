a = int(input())
prev = a - 1
nek = a + 1
print("The next number for the number " + str(a) + " is " + str(nek) + ".")
print("The previous number for the number " + str(a)  +" is " + str(prev) + ".")