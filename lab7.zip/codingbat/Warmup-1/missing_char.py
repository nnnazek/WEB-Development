def missing_char(str, n):
    pered = str[:n] 
    zad = str[n+1:]  

    return front + back