def near_hundred(n):
      if(abs(100 - n) <= 10):
    return True
  elif(abs(200 - n) <= 10):
    return True
  else:
    return False
