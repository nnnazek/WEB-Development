def sum_double(a, b):
      summ = a + b
  
  if a == b:
    summ = summ * 2
  return summ