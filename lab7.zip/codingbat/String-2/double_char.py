def double_char(str):
    result = ''
    for i in str:
        result += i
        result += i
    return result
