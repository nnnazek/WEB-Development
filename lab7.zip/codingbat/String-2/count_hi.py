def count_hi(str):
    res = str.split('hi')
    return len(res) - 1