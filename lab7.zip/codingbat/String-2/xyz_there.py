def xyz_there(str):
    str = str.replace('.xyz', '')
    if 'xyz' in str:
        return True
    else:
        return False