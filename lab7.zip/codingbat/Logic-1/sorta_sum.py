def sorta_sum(a, b):
    tot = a + b
    if tot > 9 and tot < 20:
        return 20
    else:
        return tot