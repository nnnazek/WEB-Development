def reverse3(nums):
    return [nums[2], nums[1], nums[0]]