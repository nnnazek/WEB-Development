def left2(str):
    res = str[:2]
    return str[2:] + res