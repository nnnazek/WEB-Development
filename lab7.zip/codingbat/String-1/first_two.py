def first_two(str):
    res = str[:2]
    return res