def non_start(a, b):
    return a[1:] + b[1:]