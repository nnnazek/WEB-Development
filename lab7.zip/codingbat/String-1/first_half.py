def first_half(str):
    mid = len(str) / 2
    return str[:mid]