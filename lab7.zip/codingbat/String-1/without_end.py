def without_end(str):
    res = len(str)
    return str[1:len(str) - 1]