def extra_end(str):
    # str[-2:] - is  the last two chars of the string
    res = str[-2:]
  return res*3